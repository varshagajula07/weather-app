import StatCard from "./StatCard";
import { getWeatherInfo } from "../utils/weatherCodes";
import styles from "../styles/CurrentWeather.module.css";

/**
 * CurrentWeather — shows temperature, condition, and stat grid.
 * Props:
 *   current   — weather.current object from Open-Meteo
 *   location  — geocoded location object
 */
export default function CurrentWeather({ current, location }) {
  const [description, icon] = getWeatherInfo(current.weather_code);

  const locationLabel = [location.admin1, location.country]
    .filter(Boolean)
    .join(", ");

  return (
    <div className={styles.card}>

      {/* City name + region */}
      <h2 className={styles.city}>{location.name}</h2>
      <p className={styles.region}>{locationLabel}</p>

      {/* Temperature + icon */}
      <div className={styles.tempRow}>
        <span className={styles.icon}>{icon}</span>
        <span className={styles.temp}>
          {Math.round(current.temperature_2m)}°C
        </span>
      </div>

      {/* Condition description */}
      <p className={styles.description}>{description}</p>

      {/* Stats grid */}
      <div className={styles.statsGrid}>
        <StatCard
          label="💧 Humidity"
          value={`${current.relative_humidity_2m}%`}
        />
        <StatCard
          label="💨 Wind"
          value={`${Math.round(current.wind_speed_10m)} km/h`}
        />
        <StatCard
          label="🌡️ Feels Like"
          value={`${Math.round(current.apparent_temperature)}°C`}
        />
      </div>

    </div>
  );
}
