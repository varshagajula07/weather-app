import styles from "../styles/StatCard.module.css";

/**
 * StatCard — displays a single weather metric (humidity, wind, etc.)
 * Props:
 *   label  — e.g. "💧 Humidity"
 *   value  — e.g. "72%"
 */
export default function StatCard({ label, value }) {
  return (
    <div className={styles.card}>
      <p className={styles.label}>{label}</p>
      <p className={styles.value}>{value}</p>
    </div>
  );
}
