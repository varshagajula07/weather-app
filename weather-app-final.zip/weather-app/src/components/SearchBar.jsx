import { useState } from "react";
import styles from "../styles/SearchBar.module.css";

/**
 * SearchBar component
 * Props:
 *   onSearch(query: string) — called when user submits
 *   disabled                — disables input+button while loading
 */
export default function SearchBar({ onSearch, disabled }) {
  const [query, setQuery] = useState("");

  function handleSubmit() {
    if (query.trim()) onSearch(query.trim());
  }

  function handleKeyDown(e) {
    if (e.key === "Enter") handleSubmit();
  }

  return (
    <div className={styles.wrapper}>
      <input
        className={styles.input}
        type="text"
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        onKeyDown={handleKeyDown}
        placeholder="Search city... e.g. Mumbai, London, Tokyo"
        disabled={disabled}
        aria-label="City search"
      />
      <button
        className={styles.button}
        onClick={handleSubmit}
        disabled={disabled || !query.trim()}
      >
        Search
      </button>
    </div>
  );
}
