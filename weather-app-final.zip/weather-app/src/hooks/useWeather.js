import { useState, useEffect } from "react";
import { geocodeCity, fetchForecast } from "../utils/api";

/**
 * useWeather — custom hook to manage all weather fetching logic.
 *
 * Returns:
 *   weather    — Open-Meteo forecast response (or null)
 *   location   — geocoded location object (or null)
 *   loading    — boolean
 *   error      — error string (or "")
 *   search(city) — trigger a new search
 */
export function useWeather(defaultCity = "Hyderabad") {
  const [weather, setWeather]   = useState(null);
  const [location, setLocation] = useState(null);
  const [loading, setLoading]   = useState(false);
  const [error, setError]       = useState("");

  async function search(cityName) {
    if (!cityName.trim()) return;

    setLoading(true);
    setError("");
    setWeather(null);
    setLocation(null);

    try {
      const loc  = await geocodeCity(cityName);
      const data = await fetchForecast(loc.latitude, loc.longitude);

      setLocation(loc);
      setWeather(data);
    } catch (err) {
      setError(err.message || "Something went wrong. Please try again.");
    } finally {
      setLoading(false);
    }
  }

  // Load default city on first render
  useEffect(() => {
    search(defaultCity);
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  return { weather, location, loading, error, search };
}
