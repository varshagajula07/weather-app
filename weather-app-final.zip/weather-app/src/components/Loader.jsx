import styles from "../styles/Loader.module.css";

/**
 * Loader — full-width loading indicator shown while fetching.
 */
export default function Loader() {
  return (
    <div className={styles.wrapper}>
      <div className={styles.spinner}>🌀</div>
      <p className={styles.text}>Fetching weather data...</p>
    </div>
  );
}
