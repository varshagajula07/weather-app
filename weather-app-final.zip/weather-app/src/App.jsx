import { useWeather } from "./hooks/useWeather";
import SearchBar      from "./components/SearchBar";
import CurrentWeather from "./components/CurrentWeather";
import Forecast       from "./components/Forecast";
import Loader         from "./components/Loader";
import ErrorMessage   from "./components/ErrorMessage";
import styles         from "./styles/App.module.css";

export default function App() {
  const { weather, location, loading, error, search } = useWeather("Hyderabad");

  return (
    <div className={styles.app}>

      {/* Page Header */}
      <header className={styles.header}>
        <h1>🌤️ Weather App</h1>
        <p>Live forecasts — no API key required</p>
      </header>

      {/* Search */}
      <SearchBar onSearch={search} disabled={loading} />

      {/* Error */}
      <ErrorMessage message={error} />

      {/* Loading */}
      {loading && <Loader />}

      {/* Results */}
      {!loading && weather && location && (
        <>
          <CurrentWeather current={weather.current} location={location} />
          <Forecast daily={weather.daily} />
          <p className={styles.attribution}>
            Powered by Open-Meteo — Free, No API Key Required
          </p>
        </>
      )}

    </div>
  );
}
