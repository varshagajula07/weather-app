import { getWeatherInfo, getDayLabel } from "../utils/weatherCodes";
import styles from "../styles/ForecastCard.module.css";

/**
 * ForecastCard — shows a single day's forecast tile.
 * Props:
 *   dateString  — "YYYY-MM-DD" string
 *   index       — day index (0 = Today)
 *   maxTemp     — number
 *   minTemp     — number
 *   weatherCode — WMO code
 *   rainChance  — precipitation probability (0–100 or null)
 */
export default function ForecastCard({
  dateString,
  index,
  maxTemp,
  minTemp,
  weatherCode,
  rainChance,
}) {
  const [, icon] = getWeatherInfo(weatherCode);
  const label    = getDayLabel(dateString, index);

  return (
    <div className={styles.card}>
      <p className={styles.day}>{label}</p>
      <span className={styles.icon}>{icon}</span>
      <p className={styles.hi}>{Math.round(maxTemp)}°</p>
      <p className={styles.lo}>{Math.round(minTemp)}°</p>
      {rainChance != null && (
        <p className={styles.rain}>💧 {rainChance}%</p>
      )}
    </div>
  );
}
